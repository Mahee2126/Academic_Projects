# Personality-Analysis-using-Various-Feature-Scaling-On-Dataset
<ul>
<li> Python </li>
<li>Jupyter Notebook</li>
<li>Data Analysis Libraries (numpy, panda, matplotlib. scikitlearn, tensorflow, keras)</li>
</ul>
It’s a human behavior analysis project using the data collected from our department. In this paper, we haved tried to analyze what type of attributes make a person impatient and envy of others.




![Demo Picture](https://github.com/Oishee30/Personality-Analysis-using-Various-Feature-Scaling-On-Dataset/blob/master/analysis.PNG)


