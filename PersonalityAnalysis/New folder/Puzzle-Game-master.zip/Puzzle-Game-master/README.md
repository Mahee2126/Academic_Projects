# Puzzle Game with A Star Algorithm
<h3> Tools </h3>
<ul>
<li>WebGL</li>
<li>JavaScript</li>
<li>A Star Algorithm</li>
</ul>
This game is implemented using WebGL and JavaScript. In this game user can shuffle pictures and play the game to fix the picture, user can ask for suggestion and the system will give hints using A star algorithm with the best possible move. 

[![Watch the video](https://github.com/Oishee30/Puzzle-Game/blob/master/puzzle.PNG)](https://youtu.be/05_BJo7p4ak)
