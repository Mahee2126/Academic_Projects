# Online-Super-Shop-Management-Using-Java-Servlet-and-RMI
<ul>
<li>  Java </li>
<li> Servlet</li>
<li>  RMI< /li>
<li> Bootstrap, Oracle 10g</li>
</ul>
Ecommerce based website. Users are categorized as Admin, Customer & Page Owner. Proper Sign in, Sign up validation. Admin has access to all the features. User add their products to cart or favorite list. The motivation of this project was to apply Servlet and RMI.

![Demo Picture](https://github.com/Oishee30/Online-Super-Shop-Management-Using-Java-Servlet-and-RMI/blob/master/p1.PNG)
![Demo Picture](https://github.com/Oishee30/Online-Super-Shop-Management-Using-Java-Servlet-and-RMI/blob/master/p2.PNG)


