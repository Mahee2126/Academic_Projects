var class_product =
[
    [ "getAvailability", "class_product.html#a26824d57b611d392819d5fe74cc44ed7", null ],
    [ "getCategory", "class_product.html#a3fe94b7c87c730e063377298cd06d2f3", null ],
    [ "getDetails", "class_product.html#a7e52ee55a2040ed43de668ba06305899", null ],
    [ "getId", "class_product.html#a7defaa7ccf44eaade9c514f73a8c16b0", null ],
    [ "getName", "class_product.html#a7cd7a5ab2efcd0a3214e1e7928006e1a", null ],
    [ "getPicture", "class_product.html#a5fdebffb244aadcbc3de652976af1b7d", null ],
    [ "getPrice", "class_product.html#acd98d30d99facb52c93b64783e90c7a8", null ],
    [ "getQuantity", "class_product.html#a46e0266bf10d4fe4972eea290d59b783", null ],
    [ "setAvailability", "class_product.html#aff893d8ef6f6f70bc70c5a99bb1049a3", null ],
    [ "setCategory", "class_product.html#a2403ef234d4f53d97d2e4535aa076e8d", null ],
    [ "setDetails", "class_product.html#acf9f458bbdef71e32236d6ee94748f89", null ],
    [ "setId", "class_product.html#a611c68129427dea75fa1f811b0dc19bc", null ],
    [ "setName", "class_product.html#a47566319fb32692c6c0cf2326d6a8e8d", null ],
    [ "setPicture", "class_product.html#ad04da42d2b2912956e849a8246ee3403", null ],
    [ "setPrice", "class_product.html#a58a8d85fcc80621b05492093b025e173", null ],
    [ "setQuantity", "class_product.html#a8a0578b77798b2ff33b585cc599f3172", null ]
];