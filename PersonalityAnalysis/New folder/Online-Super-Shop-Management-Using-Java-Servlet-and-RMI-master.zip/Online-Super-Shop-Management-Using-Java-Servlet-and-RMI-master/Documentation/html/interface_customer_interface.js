var interface_customer_interface =
[
    [ "getCustomer", "interface_customer_interface.html#ae6fd6f70022bbb0e6600c7bcaf3e139c", null ],
    [ "getProduct", "interface_customer_interface.html#a671bbfd3dfb9bbc58d3c9d04f38da627", null ],
    [ "loginCheck", "interface_customer_interface.html#aded022cc5a8b728bc07ded2267fd4f07", null ],
    [ "registerCustomer", "interface_customer_interface.html#ad0130eaa14a8f40060a9328aeedab244", null ],
    [ "sayHello", "interface_customer_interface.html#a9ab16776cf93e41a43e58f890189e3d1", null ]
];