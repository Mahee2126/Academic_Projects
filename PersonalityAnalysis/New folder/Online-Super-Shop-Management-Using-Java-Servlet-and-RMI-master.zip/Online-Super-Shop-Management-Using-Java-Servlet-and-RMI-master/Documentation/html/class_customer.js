var class_customer =
[
    [ "getEmail", "class_customer.html#a67b00c2a42dfe312a6482df9efb2b021", null ],
    [ "getName", "class_customer.html#a105aeee9f0f26ee9f96e8be6333dbde3", null ],
    [ "getPassword", "class_customer.html#afcea772b0128389261e4027acb75c521", null ],
    [ "setEmail", "class_customer.html#afc0161323985dd102afa764d2a030e3c", null ],
    [ "setName", "class_customer.html#a75927aaa172bff6dfd66b536486456e0", null ],
    [ "setPassword", "class_customer.html#a5b6fe587094c77007702ccf9840b54c0", null ]
];