var class_database_handler =
[
    [ "closeDatabase", "class_database_handler.html#a4ae94f3d0326a638af3ff4fb4a90e976", null ],
    [ "deleteData", "class_database_handler.html#ab63bedcd19c5e1596c6e693672cc479a", null ],
    [ "getProduct", "class_database_handler.html#a12c440f6f040a17f9f651ce9edc5d608", null ],
    [ "getTableName", "class_database_handler.html#aee7ff1913c7d5cf9453b9eca5e80648d", null ],
    [ "loginMethod", "class_database_handler.html#abedcbb21da30f991f7b93b1db5c9b829", null ],
    [ "query1", "class_database_handler.html#ace2c7efee64daaf77266b6666614e017", null ],
    [ "query2", "class_database_handler.html#a079a6fbfaebaef4ae960c884bca7ac19", null ],
    [ "query3", "class_database_handler.html#ab41175ec78b0fbe34153dae92b05ff3c", null ],
    [ "query4", "class_database_handler.html#a6dd432cfb64e9579b93da8ca1b1ccff8", null ],
    [ "query5", "class_database_handler.html#a63a618d22c1241c0d6b7165c1f1a5967", null ],
    [ "registrationMethod", "class_database_handler.html#af61e1c8fda7f53e1f1a047b1215c740e", null ],
    [ "setConnection", "class_database_handler.html#a8e77ef24c744312d8124bde6b7efd29f", null ],
    [ "showResult", "class_database_handler.html#a8130c818781d7b48cb2d46ae77090792", null ],
    [ "testQuery", "class_database_handler.html#ac6ac13dad637b902451a26d621d22cf2", null ],
    [ "updateData", "class_database_handler.html#a45a6be08d6806eaf3b2730ce40c353e8", null ]
];