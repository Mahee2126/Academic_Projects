var searchData=
[
  ['databasehandler',['DatabaseHandler',['../class_database_handler.html',1,'']]]
];
