var searchData=
[
  ['logincheck',['loginCheck',['../class_customer_inerface_impl.html#a508e5e0b67fd7dc5b0852af19d20bc31',1,'CustomerInerfaceImpl.loginCheck()'],['../interface_customer_interface.html#aded022cc5a8b728bc07ded2267fd4f07',1,'CustomerInterface.loginCheck()']]],
  ['loginmethod',['loginMethod',['../class_database_handler.html#abedcbb21da30f991f7b93b1db5c9b829',1,'DatabaseHandler']]]
];
