var searchData=
[
  ['sayhello',['sayHello',['../class_customer_inerface_impl.html#abf7eca8202321d451365ad57abe6d6de',1,'CustomerInerfaceImpl.sayHello()'],['../interface_customer_interface.html#a9ab16776cf93e41a43e58f890189e3d1',1,'CustomerInterface.sayHello()']]],
  ['setavailability',['setAvailability',['../class_product.html#aff893d8ef6f6f70bc70c5a99bb1049a3',1,'Product']]],
  ['setcategory',['setCategory',['../class_product.html#a2403ef234d4f53d97d2e4535aa076e8d',1,'Product']]],
  ['setconnection',['setConnection',['../class_database_handler.html#a8e77ef24c744312d8124bde6b7efd29f',1,'DatabaseHandler']]],
  ['setdetails',['setDetails',['../class_product.html#acf9f458bbdef71e32236d6ee94748f89',1,'Product']]],
  ['setemail',['setEmail',['../class_customer.html#afc0161323985dd102afa764d2a030e3c',1,'Customer']]],
  ['setid',['setId',['../class_product.html#a611c68129427dea75fa1f811b0dc19bc',1,'Product']]],
  ['setname',['setName',['../class_customer.html#a75927aaa172bff6dfd66b536486456e0',1,'Customer.setName()'],['../class_product.html#a47566319fb32692c6c0cf2326d6a8e8d',1,'Product.setName()']]],
  ['setpassword',['setPassword',['../class_customer.html#a5b6fe587094c77007702ccf9840b54c0',1,'Customer']]],
  ['setpicture',['setPicture',['../class_product.html#ad04da42d2b2912956e849a8246ee3403',1,'Product']]],
  ['setprice',['setPrice',['../class_product.html#a58a8d85fcc80621b05492093b025e173',1,'Product']]],
  ['setquantity',['setQuantity',['../class_product.html#a8a0578b77798b2ff33b585cc599f3172',1,'Product']]],
  ['showresult',['showResult',['../class_database_handler.html#a8130c818781d7b48cb2d46ae77090792',1,'DatabaseHandler']]]
];
