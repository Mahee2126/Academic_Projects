var searchData=
[
  ['closedatabase',['closeDatabase',['../class_database_handler.html#a4ae94f3d0326a638af3ff4fb4a90e976',1,'DatabaseHandler']]]
];
