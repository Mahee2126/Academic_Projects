var searchData=
[
  ['query1',['query1',['../class_database_handler.html#ace2c7efee64daaf77266b6666614e017',1,'DatabaseHandler']]],
  ['query2',['query2',['../class_database_handler.html#a079a6fbfaebaef4ae960c884bca7ac19',1,'DatabaseHandler']]],
  ['query3',['query3',['../class_database_handler.html#ab41175ec78b0fbe34153dae92b05ff3c',1,'DatabaseHandler']]],
  ['query4',['query4',['../class_database_handler.html#a6dd432cfb64e9579b93da8ca1b1ccff8',1,'DatabaseHandler']]],
  ['query5',['query5',['../class_database_handler.html#a63a618d22c1241c0d6b7165c1f1a5967',1,'DatabaseHandler']]]
];
