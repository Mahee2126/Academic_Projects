var searchData=
[
  ['testquery',['testQuery',['../class_database_handler.html#ac6ac13dad637b902451a26d621d22cf2',1,'DatabaseHandler']]]
];
