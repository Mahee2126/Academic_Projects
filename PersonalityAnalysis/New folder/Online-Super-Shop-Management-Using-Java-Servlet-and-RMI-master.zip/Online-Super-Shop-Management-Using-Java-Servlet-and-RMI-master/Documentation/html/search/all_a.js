var searchData=
[
  ['updatedata',['updateData',['../class_database_handler.html#a45a6be08d6806eaf3b2730ce40c353e8',1,'DatabaseHandler']]]
];
