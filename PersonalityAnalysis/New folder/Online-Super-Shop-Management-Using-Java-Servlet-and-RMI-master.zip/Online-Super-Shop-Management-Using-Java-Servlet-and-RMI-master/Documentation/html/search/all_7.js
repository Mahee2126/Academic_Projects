var searchData=
[
  ['registercustomer',['registerCustomer',['../class_customer_inerface_impl.html#aa5029a5038b56d80f3858d8e259f2f20',1,'CustomerInerfaceImpl.registerCustomer()'],['../interface_customer_interface.html#ad0130eaa14a8f40060a9328aeedab244',1,'CustomerInterface.registerCustomer()']]],
  ['registrationmethod',['registrationMethod',['../class_database_handler.html#af61e1c8fda7f53e1f1a047b1215c740e',1,'DatabaseHandler']]],
  ['rmiserver',['RMIServer',['../class_r_m_i_server.html',1,'']]],
  ['rmiserver_2ejava',['RMIServer.java',['../_r_m_i_server_8java.html',1,'']]]
];
