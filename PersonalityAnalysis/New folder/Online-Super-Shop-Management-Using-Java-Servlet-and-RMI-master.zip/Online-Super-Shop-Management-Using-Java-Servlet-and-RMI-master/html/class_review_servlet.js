var class_review_servlet =
[
    [ "doGet", "class_review_servlet.html#af10b05d96088507edaad005698c23d51", null ],
    [ "doPost", "class_review_servlet.html#a78537d2d3a3ec68c678a0da42f8d9584", null ],
    [ "getServletInfo", "class_review_servlet.html#a6fa1919d443002d575dee99be9365cbd", null ],
    [ "processRequest", "class_review_servlet.html#a4ad1599933b1a7e377ea12985a7953c1", null ]
];