var annotated_dup =
[
    [ "AddToCartServlet", "class_add_to_cart_servlet.html", "class_add_to_cart_servlet" ],
    [ "Cart", "class_cart.html", "class_cart" ],
    [ "CartServlet", "class_cart_servlet.html", "class_cart_servlet" ],
    [ "Customer", "class_customer.html", "class_customer" ],
    [ "CustomerInerfaceImpl", "class_customer_inerface_impl.html", "class_customer_inerface_impl" ],
    [ "CustomerInterface", "interface_customer_interface.html", "interface_customer_interface" ],
    [ "CustomerLoginServlet", "class_customer_login_servlet.html", "class_customer_login_servlet" ],
    [ "CustomerLogoutServelet", "class_customer_logout_servelet.html", "class_customer_logout_servelet" ],
    [ "CustomerRegisterServlet", "class_customer_register_servlet.html", "class_customer_register_servlet" ],
    [ "DatabaseHandler", "class_database_handler.html", "class_database_handler" ],
    [ "FavDeleteServlet", "class_fav_delete_servlet.html", "class_fav_delete_servlet" ],
    [ "FavoriteProductServlet", "class_favorite_product_servlet.html", "class_favorite_product_servlet" ],
    [ "FavProductViewServlet", "class_fav_product_view_servlet.html", "class_fav_product_view_servlet" ],
    [ "Product", "class_product.html", "class_product" ],
    [ "ProductDetailsServlet", "class_product_details_servlet.html", "class_product_details_servlet" ],
    [ "ProductServlet", "class_product_servlet.html", "class_product_servlet" ],
    [ "Review", "class_review.html", "class_review" ],
    [ "ReviewServlet", "class_review_servlet.html", "class_review_servlet" ],
    [ "RMIServer", "class_r_m_i_server.html", null ],
    [ "SessionCheckServlet", "class_session_check_servlet.html", "class_session_check_servlet" ],
    [ "WelcomeServelet", "class_welcome_servelet.html", "class_welcome_servelet" ]
];