var searchData=
[
  ['insertdata',['insertData',['../class_database_handler.html#a0244914bb525167cbc9420ff4277e75e',1,'DatabaseHandler']]]
];
