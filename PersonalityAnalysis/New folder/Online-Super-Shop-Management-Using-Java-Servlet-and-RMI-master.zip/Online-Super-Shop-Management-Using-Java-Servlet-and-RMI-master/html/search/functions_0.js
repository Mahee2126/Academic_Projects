var searchData=
[
  ['addtocart',['addToCart',['../class_customer_inerface_impl.html#a8a0cfac16a81783a388d4df432aaead0',1,'CustomerInerfaceImpl.addToCart()'],['../interface_customer_interface.html#a6582e16595639d15f6f2cf882ae149bd',1,'CustomerInterface.addToCart()']]],
  ['addtofav',['addToFav',['../class_customer_inerface_impl.html#ab50452f9238d8703e7cb375ba2d59f56',1,'CustomerInerfaceImpl.addToFav()'],['../interface_customer_interface.html#aed8a02f9e3ed7f10560b18487a2cb447',1,'CustomerInterface.addToFav()']]],
  ['addtoreview',['addToReview',['../class_customer_inerface_impl.html#ade13c471b397c4ffd76be5cce980bd98',1,'CustomerInerfaceImpl.addToReview()'],['../interface_customer_interface.html#aa7927ead20ce4e81eb3ed2dfdd9d7ae9',1,'CustomerInterface.addToReview()']]]
];
