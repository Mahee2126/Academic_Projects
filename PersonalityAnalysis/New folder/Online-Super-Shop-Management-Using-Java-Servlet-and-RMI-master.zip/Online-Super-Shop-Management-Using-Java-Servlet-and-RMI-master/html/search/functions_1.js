var searchData=
[
  ['checkout',['checkOut',['../class_cart.html#ac0180a35c52603fcd145a52344f957ad',1,'Cart']]],
  ['closedatabase',['closeDatabase',['../class_database_handler.html#a4ae94f3d0326a638af3ff4fb4a90e976',1,'DatabaseHandler']]]
];
