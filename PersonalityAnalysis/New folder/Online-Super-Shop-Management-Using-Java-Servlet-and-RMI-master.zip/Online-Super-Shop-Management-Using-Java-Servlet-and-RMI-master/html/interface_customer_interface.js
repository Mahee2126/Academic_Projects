var interface_customer_interface =
[
    [ "addToCart", "interface_customer_interface.html#a6582e16595639d15f6f2cf882ae149bd", null ],
    [ "addToFav", "interface_customer_interface.html#aed8a02f9e3ed7f10560b18487a2cb447", null ],
    [ "addToReview", "interface_customer_interface.html#aa7927ead20ce4e81eb3ed2dfdd9d7ae9", null ],
    [ "deleteFromFav", "interface_customer_interface.html#a28885e1e47bcba4099fbe3acda248b7f", null ],
    [ "getCart", "interface_customer_interface.html#a7ed9da53fd07eb9948379dad761e9505", null ],
    [ "getCustomer", "interface_customer_interface.html#ae6fd6f70022bbb0e6600c7bcaf3e139c", null ],
    [ "getFavProduct", "interface_customer_interface.html#aecc9cd099debac9f075336429dd799da", null ],
    [ "getProduct", "interface_customer_interface.html#a671bbfd3dfb9bbc58d3c9d04f38da627", null ],
    [ "getProductInfo", "interface_customer_interface.html#a3b767e1a17de76c7fce69b9919490177", null ],
    [ "getReview", "interface_customer_interface.html#aa14b879b5dab75bd4a6bf6ab5620f0d3", null ],
    [ "loginCheck", "interface_customer_interface.html#aded022cc5a8b728bc07ded2267fd4f07", null ],
    [ "registerCustomer", "interface_customer_interface.html#ad0130eaa14a8f40060a9328aeedab244", null ],
    [ "sayHello", "interface_customer_interface.html#a9ab16776cf93e41a43e58f890189e3d1", null ]
];