var class_review =
[
    [ "getPid", "class_review.html#a8e2dca65f1379d5b771d9ea09e741ac1", null ],
    [ "getReview", "class_review.html#afbb9d7730f5b608da29552e4d44c5a11", null ],
    [ "getUser", "class_review.html#a2735d299d10e0a9e421709d661099d3e", null ],
    [ "setPid", "class_review.html#a8ec3f5953a4a2bb54ed0a0237d3e58eb", null ],
    [ "setReview", "class_review.html#a99f9f5f026da5b49a7bf1ddecff11c2b", null ],
    [ "setUser", "class_review.html#af9cbd1bf8547d3f016081e13d75478f8", null ]
];