var class_fav_delete_servlet =
[
    [ "doGet", "class_fav_delete_servlet.html#a5661640e81b8a08a965bb76c179d4129", null ],
    [ "doPost", "class_fav_delete_servlet.html#a16a5b35bdfa47712eefcf3eb50b85837", null ],
    [ "getServletInfo", "class_fav_delete_servlet.html#aabfa30d4cba121ab3e601448c9713dbf", null ],
    [ "processRequest", "class_fav_delete_servlet.html#af916e8585ee32612595ce99dbe18e7db", null ]
];