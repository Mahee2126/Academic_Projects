var files_dup =
[
    [ "AddToCartServlet.java", "_add_to_cart_servlet_8java.html", [
      [ "AddToCartServlet", "class_add_to_cart_servlet.html", "class_add_to_cart_servlet" ]
    ] ],
    [ "Cart.java", "_cart_8java.html", [
      [ "Cart", "class_cart.html", "class_cart" ]
    ] ],
    [ "CartServlet.java", "_cart_servlet_8java.html", [
      [ "CartServlet", "class_cart_servlet.html", "class_cart_servlet" ]
    ] ],
    [ "Customer.java", "_customer_8java.html", [
      [ "Customer", "class_customer.html", "class_customer" ]
    ] ],
    [ "CustomerInerfaceImpl.java", "_customer_inerface_impl_8java.html", [
      [ "CustomerInerfaceImpl", "class_customer_inerface_impl.html", "class_customer_inerface_impl" ]
    ] ],
    [ "CustomerInterface.java", "_customer_interface_8java.html", [
      [ "CustomerInterface", "interface_customer_interface.html", "interface_customer_interface" ]
    ] ],
    [ "CustomerLoginServlet.java", "_customer_login_servlet_8java.html", [
      [ "CustomerLoginServlet", "class_customer_login_servlet.html", "class_customer_login_servlet" ]
    ] ],
    [ "CustomerLogoutServelet.java", "_customer_logout_servelet_8java.html", [
      [ "CustomerLogoutServelet", "class_customer_logout_servelet.html", "class_customer_logout_servelet" ]
    ] ],
    [ "CustomerRegisterServlet.java", "_customer_register_servlet_8java.html", [
      [ "CustomerRegisterServlet", "class_customer_register_servlet.html", "class_customer_register_servlet" ]
    ] ],
    [ "DatabaseHandler.java", "_database_handler_8java.html", [
      [ "DatabaseHandler", "class_database_handler.html", "class_database_handler" ]
    ] ],
    [ "FavDeleteServlet.java", "_fav_delete_servlet_8java.html", [
      [ "FavDeleteServlet", "class_fav_delete_servlet.html", "class_fav_delete_servlet" ]
    ] ],
    [ "FavoriteProductServlet.java", "_favorite_product_servlet_8java.html", [
      [ "FavoriteProductServlet", "class_favorite_product_servlet.html", "class_favorite_product_servlet" ]
    ] ],
    [ "FavProductViewServlet.java", "_fav_product_view_servlet_8java.html", [
      [ "FavProductViewServlet", "class_fav_product_view_servlet.html", "class_fav_product_view_servlet" ]
    ] ],
    [ "Product.java", "_product_8java.html", [
      [ "Product", "class_product.html", "class_product" ]
    ] ],
    [ "ProductDetailsServlet.java", "_product_details_servlet_8java.html", [
      [ "ProductDetailsServlet", "class_product_details_servlet.html", "class_product_details_servlet" ]
    ] ],
    [ "ProductServlet.java", "_product_servlet_8java.html", [
      [ "ProductServlet", "class_product_servlet.html", "class_product_servlet" ]
    ] ],
    [ "Review.java", "_review_8java.html", [
      [ "Review", "class_review.html", "class_review" ]
    ] ],
    [ "ReviewServlet.java", "_review_servlet_8java.html", [
      [ "ReviewServlet", "class_review_servlet.html", "class_review_servlet" ]
    ] ],
    [ "RMIServer.java", "_r_m_i_server_8java.html", [
      [ "RMIServer", "class_r_m_i_server.html", null ]
    ] ],
    [ "SessionCheckServlet.java", "_session_check_servlet_8java.html", [
      [ "SessionCheckServlet", "class_session_check_servlet.html", "class_session_check_servlet" ]
    ] ],
    [ "WelcomeServelet.java", "_welcome_servelet_8java.html", [
      [ "WelcomeServelet", "class_welcome_servelet.html", "class_welcome_servelet" ]
    ] ]
];